# OAI-PMH для tplegacy.net

Двочастинний OAI-PMH 2.0 ендпоінт:

- **Генерація** — `generator/build_oai_dataset.py` запускається в GitHub Actions
  раз на тиждень, тягне пости з Ghost Content API, мапить у Dublin Core (`oai_dc`)
  і пише `data/oai-dataset.json`. Файл комітиться й роздається через jsDelivr.
- **Віддача** — `worker/worker.js` це Cloudflare Worker, що читає датасет і
  відповідає на живі OAI-PMH запити (шість verbs, фільтр `from`/`until`/`set`,
  resumption tokens). Адреса: `https://tplegacy-oai.<субдомен>.workers.dev/oai`.

```
GitHub Actions (щотижня) ──> data/oai-dataset.json ──> jsDelivr (CDN)
                                                            │
харвестер ──> ...workers.dev/oai?verb=... ──> Cloudflare Worker ──┘
```

## Структура репозиторію

Усе це — ОДИН публічний GitHub-репозиторій. Файли лежать так:

```
tplegacy-oai/
├── .github/
│   └── workflows/
│       └── build-oai.yml          ← розклад збірки (GitHub знаходить тут автоматично)
├── generator/
│   └── build_oai_dataset.py       ← Ghost → Dublin Core
├── worker/
│   ├── worker.js                  ← Cloudflare Worker (звідси деплоїться)
│   └── wrangler.toml              ← конфіг деплою воркера
├── data/
│   └── oai-dataset.json           ← з'являється САМ після першого запуску workflow
└── README.md
```

Важливо:
- `.github/workflows/` — спеціальний шлях, який GitHub розпізнає сам. Не перейменовуй.
- Папку `data/` створювати руками НЕ треба — перший запуск workflow зробить це сам.
- Воркер живе в цьому ж репо (для версіонування), але деплоїться окремо командою
  `wrangler deploy` з папки `worker/`.

## Як завести (крок за кроком)

1. **Створи публічний репозиторій** на GitHub з назвою `tplegacy-oai`.
   Має бути саме **public** — jsDelivr роздає лише з публічних репо.
   (Якщо назвеш інакше — заміни `Jon-tplegacy/tplegacy-oai` у `worker.js` →
   `DATA_URL` і в `build-oai.yml` → purge-URL.)

2. **Заллий файли** в тій структурі, що вище (або розпакуй наданий zip).

3. **Заповни два плейсхолдери:**
   - `worker/worker.js` → `BASE_URL`: підстав свій `<субдомен>` (його надрукує
     `wrangler deploy` наприкінці).
   - CONFIG-блок у `generator/build_oai_dataset.py`: підлаштуй `CREATOR_MAP`,
     `LANG_PREFIX`, `RIGHTS` та ARK-схему під свою таксономію тегів.

4. **Додай секрети** (Settings → Secrets and variables → Actions):
   - `GHOST_API_URL` = `https://tplegacy.net`
   - `GHOST_CONTENT_API_KEY` = твій read-only Content API key

5. **Перший запуск.** Actions → Build OAI-PMH dataset → Run workflow.
   Створить `data/oai-dataset.json` і скине кеш jsDelivr.

6. **Задеплой воркер.**
   ```
   cd worker
   npx wrangler deploy
   ```
   Скопіюй надруковану адресу, встав `<субдомен>` у `BASE_URL`, задеплой ще раз.

## Перевірка

```
curl "https://tplegacy-oai.<субдомен>.workers.dev/oai?verb=Identify"
curl "https://tplegacy-oai.<субдомен>.workers.dev/oai?verb=ListSets"
curl "https://tplegacy-oai.<субдомен>.workers.dev/oai?verb=ListRecords&metadataPrefix=oai_dc"
```

Прожени через OAI-PMH валідатор, перш ніж реєструвати.

## Реєстрація baseURL

Подай `https://tplegacy-oai.<субдомен>.workers.dev/oai` у BASE, CORE, OpenAIRE.
Після реєстрації НЕ міняй ні назву воркера, ні субдомен акаунта — інакше адреса
зміниться, і доведеться перереєстровуватись.

## Нотатки / межі

- **Лише метадані.** У `dc:identifier` лежать ARK + canonical URL, без повнотексту —
  це стандарт для харвестерів.
- **Видалення.** `deletedRecord` = `no`: пост, прибраний з Ghost, просто зникає
  з датасету; сигналу про видалення харвестер не отримує. Для архіву це норма.
- **Без ліміту записів.** Воркер пагінує будь-який обсяг. (Ліміт 5000 стосується
  лише стандарту OAI Static Repository, який тут не використовується.)
- **Секрети безпечні** у публічному репо: ключ читається з GitHub Secrets, у код
  і логи не потрапляє. Просто не закоміть його руками.
- **Свіжість.** jsDelivr скидається після кожної збірки; воркер ще й кешує датасет
  на edge на годину (`EDGE_TTL`).
```
